import pickle

class DAO:
    def __init__(self):
        self.__datasource = "dados_sistema.pkl"

    def salvar(self, dados):
        with open(self.__datasource, 'wb') as arquivo:
            pickle.dump(dados, arquivo)

    def carregar(self):
        try:
            
            with open(self.__datasource, 'rb') as arquivo:
                return pickle.load(arquivo)
        except FileNotFoundError:
            return {"pacientes": [], "profissionais": [], "clinicas": [], "atendimentos": []}